package main

import "github.com/WeAreTheSameBlood/malva-cli/cmd"

func main() {
	cmd.Execute()
}
